<?php
class ModelExtensionOpenBayEtsyProduct extends Model {
	public function inbound($data) {

	}
}